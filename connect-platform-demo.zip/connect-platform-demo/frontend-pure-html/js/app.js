// 企业 Connect 平台 - 兼容版 (ES5语法)
(function(){
  'use strict';
  
  console.log('企业 Connect 平台启动...');
  
  // ===== 核心状态 =====
  var STORAGE_KEY = 'cc_demo_state_v1';
  var defaultState = {
    panel: 'home',
    theme: 'default',
    user: {
      company: '示例科技有限公司',
      industry: '科技/互联网',
      website: 'https://mycompany.com',
      shop: ['企业咨询服务', '软件定制开发', '数据分析服务', 'AI模型训练服务'],
      tags: ['软件开发', '企业服务']
    },
    exampleWebsites: [
      { name: '科技公司官网', url: 'https://tech.example.com', desc: '现代化科技企业官网' },
      { name: '电商店铺', url: 'https://shop.example.com', desc: '在线商城，支持购物' },
      { name: '企业博客', url: 'https://blog.example.com', desc: '行业资讯分享' }
    ],
    templates: [
      { id: 'hero', label: '欢迎横幅', enabled: true, content: '欢迎来到我们的创新社区' },
      { id: 'about', label: '关于我们', enabled: true, content: '专注于企业服务的科技公司' },
      { id: 'services', label: '服务预览', enabled: true, content: '提供全方位技术服务' }
    ]
  };
  
  // ===== 工具函数 =====
  function $(sel) { return document.querySelector(sel); }
  function $$(sel) { return document.querySelectorAll(sel); }
  
  function saveState(state) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch(e) {
      console.warn('保存状态失败:', e);
    }
  }
  
  function loadState() {
    try {
      var saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch(e) {
      console.warn('加载状态失败:', e);
      return null;
    }
  }
  
  var state = loadState() || defaultState;
  
  // ===== 首页渲染 =====
  function renderHome() {
    console.log('渲染首页...');
    var container = $('#tagBubble');
    if (container) {
      container.innerHTML = '<p>首页内容加载成功！</p>';
    }
  }
  
  // ===== 店铺页面渲染 =====
  function renderSite() {
    console.log('渲染店铺页面...');
    var container = $('#siteProfile');
    if (!container) {
      console.error('找不到 siteProfile 容器');
      return;
    }
    
    var html = '';
    html += '<section class="section">';
    html += '  <div class="section-title">企业官网</div>';
    html += '  <div class="form-group">';
    html += '    <label class="form-label">官网地址</label>';
    html += '    <input type="url" id="siteUrl" class="form-input" value="' + state.user.website + '" />';
    html += '  </div>';
    html += '  <div class="form-group">';
    html += '    <label class="form-label">官网状态</label>';
    html += '    <div class="status-badge active">已发布</div>';
    html += '  </div>';
    html += '</section>';
    
    html += '<section class="section">';
    html += '  <div class="section-title">官网示例</div>';
    html += '  <div class="example-grid">';
    
    for (var i = 0; i < state.exampleWebsites.length; i++) {
      var site = state.exampleWebsites[i];
      html += '    <div class="example-card">';
      html += '      <div class="example-card-header">';
      html += '        <span class="example-icon">🌐</span>';
      html += '        <span class="example-name">' + site.name + '</span>';
      html += '      </div>';
      html += '      <p class="example-desc">' + site.desc + '</p>';
      html += '      <a href="' + site.url + '" target="_blank" class="example-link">访问示例 →</a>';
      html += '    </div>';
    }
    
    html += '  </div>';
    html += '</section>';
    
    html += '<section class="section">';
    html += '  <div class="section-title">我的商品 <span class="tag badge">' + state.user.shop.length + ' 项</span></div>';
    html += '  <div class="shop-stats">';
    html += '    <div class="stat-item">';
    html += '      <span class="stat-label">总商品数</span>';
    html += '      <span class="stat-value">' + state.user.shop.length + '</span>';
    html += '    </div>';
    html += '    <div class="stat-item">';
    html += '      <span class="stat-label">月销量</span>';
    html += '      <span class="stat-value">128</span>';
    html += '    </div>';
    html += '    <div class="stat-item">';
    html += '      <span class="stat-label">好评率</span>';
    html += '      <span class="stat-value">98%</span>';
    html += '    </div>';
    html += '  </div>';
    html += '  <ul class="shop-list">';
    
    for (var j = 0; j < state.user.shop.length; j++) {
      var item = state.user.shop[j];
      html += '    <li class="shop-item">';
      html += '      <span class="shop-item-icon">📦</span>';
      html += '      <span class="shop-item-name">' + item + '</span>';
      html += '      <span class="shop-item-price">¥' + ((j + 1) * 999) + '</span>';
      html += '      <span class="shop-item-sales">销量: ' + ((j + 1) * 23) + '</span>';
      html += '    </li>';
    }
    
    html += '  </ul>';
    html += '  <div class="shop-actions">';
    html += '    <button onclick="addShopItem()" class="btn shop-btn">+ 添加商品</button>';
    html += '  </div>';
    html += '</section>';
    
    container.innerHTML = html;
    
    // 绑定官网地址更新
    var urlInput = $('#siteUrl');
    if (urlInput) {
      urlInput.addEventListener('input', function(e) {
        state.user.website = e.target.value;
        saveState(state);
      });
    }
    
    console.log('店铺页面渲染完成');
  }
  
  // ===== 全局函数 =====
  window.addShopItem = function() {
    var item = prompt('请输入商品名称：', '新商品');
    if (item && item.trim()) {
      state.user.shop.push(item.trim());
      saveState(state);
      renderSite();
      alert('商品添加成功！');
    }
  };
  
  window.toggleTemplate = function(id) {
    for (var i = 0; i < state.templates.length; i++) {
      if (state.templates[i].id === id) {
        state.templates[i].enabled = !state.templates[i].enabled;
        saveState(state);
        renderSite();
        break;
      }
    }
  };
  
  // ===== 面板切换 =====
  function switchPanel(panelId) {
    // 更新状态
    state.panel = panelId;
    saveState(state);
    
    // 更新导航按钮
    var buttons = $$('.nav-btn');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].classList.remove('active');
      if (buttons[i].getAttribute('data-panel') === panelId) {
        buttons[i].classList.add('active');
      }
    }
    
    // 更新面板显示
    var panels = $$('.panel');
    for (var j = 0; j < panels.length; j++) {
      panels[j].classList.remove('active');
      if (panels[j].id === 'panel-' + panelId) {
        panels[j].classList.add('active');
      }
    }
    
    // 渲染对应面板
    if (panelId === 'home') {
      renderHome();
    } else if (panelId === 'site') {
      renderSite();
    }
  }
  
  // ===== 初始化 =====
  function init() {
    console.log('初始化应用...');
    
    // 绑定导航按钮
    var buttons = $$('.nav-btn');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener('click', function() {
        var panelId = this.getAttribute('data-panel');
        console.log('切换到:', panelId);
        switchPanel(panelId);
      });
    }
    
    // 绑定主题切换
    var themeBtn = $('#themeToggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', function() {
        state.theme = state.theme === 'default' ? 'warm' : 'default';
        document.documentElement.setAttribute('data-theme', state.theme);
        saveState(state);
      });
    }
    
    // 应用保存的主题
    if (state.theme) {
      document.documentElement.setAttribute('data-theme', state.theme);
    }
    
    // 显示保存的面板
    switchPanel(state.panel);
    
    console.log('初始化完成');
  }
  
  // 启动应用
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
})();
