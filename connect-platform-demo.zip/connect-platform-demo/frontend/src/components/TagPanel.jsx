import React from 'react'

export default function TagPanel({ tags, onRemove }){
  return (
    <div className="tag-bubble">
      {tags.map((t,i)=> (
        <span key={i} className="tag" title="移除" onClick={()=>onRemove(i)}>{t} <span className="hide">×</span></span>
      ))}
    </div>
  )
}
