import React, { useEffect, useMemo, useState } from 'react'

// Simple, self-contained SPA for MVP deployment
  const defaultState = {
  user: {
    name: '未命名企业',
    industry: '科技/初创',
    company: '示例公司',
    tags: [], // 公开标签
    hiddenTags: [], // 平台可见标签
    website: 'https://example.dev',
    shop: [],
  },
  resources: [
    { id: 1, title: '共享办公位 • 月租', owner: 'A创投', desc: '适合初创团队的灵活办公位，含前台与会议室', tags: ['办公','场地'] },
    { id: 2, title: '财务记账外包', owner: '金算盘', desc: '小微企业月度记账、报税，合规快速', tags: ['财务','合规'] },
    { id: 3, title: '合同法务快速咨询', owner: '法务通', desc: '合同审核、条款优化，24小时内回复', tags: ['法务','合同'] },
  ],
  messages: [],
  services: [
    { id: 's1', name: '办公场地', summary: '联合办公位、会议室订阅/按次', price: '起/小时' },
    { id: 's2', name: '财务服务', summary: '记账、报税等财务外包', price: '月费套餐' },
    { id: 's3', name: '法务服务', summary: '合同审核、法律咨询', price: '咨询费/套餐' },
    { id: 's4', name: '人事服务', summary: '社保代缴、招聘支持', price: '按人数月费' },
    { id: 's5', name: '出纳服务', summary: '代收/付款、报销', price: '按笔/月费' },
  ],
  panel: 'home', // home|messages|services|site|me|network
  // Networking module: basic contact management and connection requests
  network: {
    contacts: [
      { id: 'n1', name: '张伟', company: '星火科技', position: 'CTO', bio: '关注AI与SaaS领域', tags: ['技术','投资对接'], public: true, connected: false, requests: [] },
      { id: 'n2', name: '李娜', company: '海蓝传媒', position: '市场总监', bio: '对接行业资源与落地渠道', tags: ['渠道','市场'], public: true, connected: false, requests: [] }
    ],
    // 简单的共享记录（示意）
    sharedRecs: []
  },
  // 现有结构上的兼容性
  bookingDraft: null,
  theme: 'default', // default | warm
  siteTemplates: [
    { id: 'hero', label: 'Hero Banner', enabled: true, content: '欢迎来到我们的创新社区', order: 0 },
    { id: 'about', label: '关于我们', enabled: true, content: '我们致力于帮助初创企业以低成本获取运营能力', order: 1 },
    { id: 'services', label: '服务预览', enabled: true, content: '展示核心共享服务', order: 2 },
    { id: 'testimonials', label: '客户感言', enabled: false, content: '客户的评价示例', order: 3 },
  ],
}

const StorageKey = 'cc_demo_frontend_state_v1'

function save(state){ localStorage.setItem(StorageKey, JSON.stringify(state)) }
function load(){ try { const s = localStorage.getItem(StorageKey); return s ? JSON.parse(s) : null } catch(e){ return null }}

function TagChip({name, onRemove}){
  return (
    <span className="tag" title="移除标签" onClick={onRemove}>
      {name} <span className="hide" style={{marginLeft:6}}>×</span>
    </span>
  )
}

function App(){
  const [state, setState] = useState(load() || defaultState)
  useEffect(()=>{ save(state) }, [state])
  // Load theme from localStorage on mount
  useEffect(()=>{ const t = localStorage.getItem('cc_theme'); if(t==='default' || t==='warm'){ setState(s => ({...s, theme: t})); } }, [])

  function toggleTheme(){ const next = state.theme === 'default' ? 'warm' : 'default'; setState(s => ({...s, theme: next})); localStorage.setItem('cc_theme', next); }

  // derived helpers
  const allPublicTags = useMemo(() => state.user.tags, [state.user.tags])
  const allHiddenTags = useMemo(() => state.user.hiddenTags, [state.user.hiddenTags])

  function addTag(value, type){ if(!value) return; if(type==='公开'){ setState(s => ({...s, user: { ...s.user, tags: [...s.user.tags, value] }})) } else { setState(s => ({...s, user: { ...s.user, hiddenTags: [...s.user.hiddenTags, value] }})) } }

  function removeTag(index, type){ if(type==='公开'){ setState(s => { const arr=[...s.user.tags]; arr.splice(index,1); return {...s, user: {...s.user, tags: arr}} }) } else { setState(s => { const arr=[...s.user.hiddenTags]; arr.splice(index,1); return {...s, user: {...s.user, hiddenTags: arr}} }) } }

  function addResourceRequest(target, title){ const m = { id: Date.now(), type: 'request', from: '你', to: target, text: `对接请求：${title}`, ts: new Date().toLocaleTimeString() }; setState(s => ({...s, messages: [m, ...s.messages]})); }

  function submitBooking(serviceName, date, hours){ const m = { id: Date.now(), type: 'booking', text: `已提交预约：${serviceName}，日期 ${date}，时长 ${hours}h`, ts: new Date().toLocaleTimeString() }; setState(s => ({...s, messages: [m, ...s.messages]})); setState(s => ({...s, bookingDraft: null, panel: 'messages'})); }

  // Panels components inside for simplicity
  const HomePanel = () => (
    <div className="panel-content">
      {state.siteTemplates.filter(t=>t.enabled).sort((a,b)=> a.order - b.order).map(t => {
        if(t.id==='hero') return (
          <section key="hero" className="section">
            <div className="hero" style={{padding: '16px', borderRadius: 12, background: 'linear-gradient(135deg,#e6f0ff 0%, #ffffff 60%)'}}>
              <h2 style={{margin:0}}>{t.content}</h2>
              <p style={{color:'#555'}}>主页模版 - Hero 标识区域</p>
            </div>
          </section>
        );
        if(t.id==='about') return (
          <section key="about" className="section"><h3 className="section-title">关于我们</h3><p>{t.content}</p></section>
        );
        if(t.id==='services') return (
          <section key="services" className="section"><h3 className="section-title">服务预览</h3><div className="grid">{state.services.slice(0,3).map(s => (
            <div className="card" key={s.id}>
              <strong>{s.name}</strong>
              <p>{s.summary}</p>
            </div>
          ))}</div></section>
        );
        if(t.id==='testimonials') return (
          <section key="testimonials" className="section"><h3 className="section-title">客户感言</h3><p>{t.content}</p></section>
        );
        return null;
      })}
    </div>
  )

  // Network Panel: basic contact management and connection requests
  const NetworkPanel = () => {
    // Local helpers
    const list = state.network.contacts;
    function addContact(){
      const name = prompt('联系人姓名');
      if(!name) return;
      const c = { id: 'n' + (state.network.contacts.length+1), name, company: '', position: '', bio: '', tags: [], public: true, connected: false };
      setState(s => ({...s, network: { ...s.network, contacts: [c, ...s.network.contacts] }}));
    }
    function sendRequest(contact){ // create a request message
      setState(s => {
        // update contact to mark pending
        const updated = s.network.contacts.map(x => x.id===contact.id ? { ...x, requests: [...(x.requests||[]), 'pending'] , public:true } : x);
        const msg = { id: Date.now(), type: 'connection', from: '你', to: contact.name, text: `认识请求：${contact.name}，来自平台` , ts: new Date().toLocaleTimeString() };
        return { ...s, network: { ...s.network, contacts: updated }, messages: [msg, ...s.messages] };
      });
    }
    function accept(contact){ setState(s => {
      const updated = s.network.contacts.map(x => x.id===contact.id ? { ...x, connected: true, requests: [] } : x);
      const msg = { id: Date.now(), type: 'connection', from: contact.name, to: '你', text: `已接受与你的认识请求：${contact.name}` , ts: new Date().toLocaleTimeString() };
      return { ...s, network: { ...s.network, contacts: updated }, messages: [msg, ...s.messages] };
    }) }
    return (
      <div className="panel-content" style={{padding:0}}>
        <section className="section" style={{marginTop:0}}>
          <h3 className="section-title">公开人脉（可见）</h3>
          <button className="btn" onClick={addContact}>新建联系人</button>
          <div className="grid" style={{marginTop:8}}>
            {list.map(c => (
              <div className="card" key={c.id} style={{display:'flex', flexDirection:'column'}}>
                <strong>{c.name}</strong>
                <span style={{fontSize:12, color:'#666'}}>{c.company} · {c.position}</span>
                <div className="tag-bubble" style={{marginTop:6}}>
                  {c.tags.map((t,i)=> <span className="tag" key={i}>{t}</span>)}
                </div>
                <div style={{marginTop:'6px', display:'flex', gap:'6px'}}>
                  {!c.connected && <button className="btn" onClick={()=>sendRequest(c)}>认识一下</button>}
                  {c.connected && <span style={{color:'#10b981', fontWeight:600}}>已认识</span>}
                  {c.connected && <button className="btn" style={{background:'#6b7280'}} onClick={()=>accept(c)}>确认连接</button>}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    )
  }

  const MessagesPanel = () => (
    <div className="panel-content">
      <h3 className="section-title">消息</h3>
      <div className="messages">
        {state.messages.length===0 ? <div className="message">暂无新消息</div> : state.messages.map(m => (
          <div className="message" key={m.id}>
            <div style={{fontWeight:600}}>{m.from || '系统'} → {m.to || ''}</div>
            <div>{m.text}</div>
            <div style={{fontSize:11, color:'#999'}}>{m.ts}</div>
          </div>
        ))}
      </div>
    </div>
  )

  const ServicesPanel = () => (
    <div className="panel-content">
      <h3 className="section-title">共享服务入口</h3>
      <div className="grid">
        {state.services.map(s => (
          <div className="card" key={s.id}>
            <strong>{s.name}</strong>
            <p>{s.summary}</p>
            <p style={{color:'#666', fontSize:12}}>价格: {s.price}</p>
            <button className="btn" style={{marginTop:6}} onClick={()=>{ setState(s0=>({ ...s0, bookingDraft: { service: s.name, date: '', hours: 1 } })); }}>申请/预约</button>
          </div>
        ))}
      </div>
      {state.bookingDraft && (
        <div className="section" style={{marginTop:12}}>
          <h4>预约：{state.bookingDraft.service}</h4>
          <div style={{display:'flex', gap:8, alignItems:'center'}}>
            <input type="date" id="bkDate" />
            <input type="number" id="bkHours" min={1} max={8} defaultValue={1} />
            <button className="btn" onClick={()=>{ const d=document.getElementById('bkDate').value; const h=document.getElementById('bkHours').value; submitBooking(state.bookingDraft.service, d, h); }}>提交</button>
          </div>
        </div>
      )}
    </div>
  )

  const SitePanel = () => (
    <div className="panel-content">
      <h3 className="section-title">官网/店铺</h3>
      <div className="section">
        <label>官网: <input value={state.user.website} onChange={e=>setState(s=>({ ...s, user: { ...s.user, website: e.target.value } }))} /></label>
      </div>
      <div className="section">
        <label>店铺商品 (示例):</label>
        <ul>
          {state.user.shop.map((it, idx)=> <li key={idx}>{it}</li>)}
        </ul>
        <button className="btn" onClick={()=>{ const item = prompt('添加商品名称：','示例商品'); if(item){ setState(s=>({ ...s, user: { ...s.user, shop: [...s.user.shop, item] } })) } }}>添加商品</button>
      </div>
      <section className="section">
        <h3 className="section-title">主页模板编辑</h3>
        <div>
          {state.siteTemplates.map((t)=> (
            <div key={t.id} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'6px 0' }}>
              <label>
                <input type="checkbox" checked={t.enabled} onChange={e=>{ const val = e.target.checked; setState(s=>({ ...s, siteTemplates: s.siteTemplates.map(x => x.id===t.id ? { ...x, enabled: val } : x) })); }} /> {t.label}
              </label>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <button onClick={()=>moveTemplate(t.id, -1)}>↑</button>
                <button onClick={()=>moveTemplate(t.id, +1)}>↓</button>
                <input value={t.content} onChange={e=>updateTemplateContent(t.id, e.target.value)} style={{width:260}}/>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )

  const MePanel = () => (
    <div className="panel-content">
      <h3 className="section-title">我的信息</h3>
      <div className="section">
        <label>公司名称: <input value={state.user.company} onChange={e=>setState(s=>({ ...s, user: { ...s.user, company: e.target.value } }))} /></label>
        <label>行业: <input value={state.user.industry} onChange={e=>setState(s=>({ ...s, user: { ...s.user, industry: e.target.value } }))} /></label>
        <label>官网: <input value={state.user.website} onChange={e=>setState(s=>({ ...s, user: { ...s.user, website: e.target.value } }))} /></label>
      </div>
      <div className="section">
        <label>新增公开标签</label>
        <input id="plusPublicTag" placeholder="标签名" />
        <button className="btn" onClick={()=>{ const v=document.getElementById('plusPublicTag').value.trim(); if(v){ addTag(v,'公开'); document.getElementById('plusPublicTag').value=''; } }}>添加</button>
      </div>
      <div className="section">
        <h4>我的标签</h4>
        <div className="tag-bubble">
          {state.user.tags.map((t,i)=> <TagChip key={`tag-${i}`} name={t} onRemove={()=>removeTag(i, '公开')} />)}
        </div>
      </div>
    </div>
  )

  // Template helpers for homepage editing
  function updateTemplateContent(tid, content){ setState(s => { const updated = s.siteTemplates.map(t => t.id===tid ? { ...t, content } : t); return {...s, siteTemplates: updated}; }); }
  function updateTemplateEnabled(tid, enabled){ setState(s => { const updated = s.siteTemplates.map(t => t.id===tid ? { ...t, enabled } : t); return {...s, siteTemplates: updated}; }); }
  function moveTemplate(tid, dir){ setState(s => {
      const list = [...s.siteTemplates].sort((a,b)=> a.order - b.order);
      const i = list.findIndex(x => x.id === tid); if(i<0) return s; const j = Math.max(0, Math.min(list.length-1, i + dir)); const swapped = list.slice(); const tmp = swapped[i]; swapped[i] = swapped[j]; swapped[j] = tmp;
      const updated = swapped.map((t, idx) => ({...t, order: idx}));
      return {...s, siteTemplates: updated};
    }) }
  
  return (
    <div className={`app theme-${state.theme}`}>
      <header className="topbar">
        <div className="brand">初创企业 · 人脉共享 Demo</div>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <button className="btn" style={{padding:'6px 10px'}} onClick={toggleTheme}>风格切换</button>
        </div>
      </header>
      <main className="content">
        {state.panel === 'home' && <HomePanel />}
        {state.panel === 'messages' && <MessagesPanel />}
        {state.panel === 'services' && <ServicesPanel />}
        {state.panel === 'site' && <SitePanel />}
        {state.panel === 'me' && <MePanel />}
        {state.panel === 'network' && <NetworkPanel />}
      </main>
      <nav className="bottom-nav" aria-label="底部导航">
        { id:'network', label:'人脉' },
        [
          {id:'home', label:'首页'},
          {id:'messages', label:'消息'},
          {id:'services', label:'服务'},
          {id:'site', label:'官网/店铺'},
          {id:'me', label:'我的'},
        ].flat().concat([
          { id:'network', label:'人脉' }
        ]).map(n => (
          <button key={n.id} className={`nav-btn ${state.panel===n.id?'active':''}`} onClick={()=>setState(s=>({ ...s, panel: n.id }))}>{n.label}</button>
        ))}
      </nav>
    </div>
  )
}

export default App
